define(
"dojo/cldr/nls/tr/currency", //begin v1.x content
{
	"HKD_displayName": "Hong Kong Doları",
	"CHF_displayName": "İsviçre Frangı",
	"JPY_symbol": "¥",
	"CAD_displayName": "Kanada Doları",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Çin Yuanı",
	"USD_symbol": "$",
	"AUD_displayName": "Avustralya Doları",
	"JPY_displayName": "Japon Yeni",
	"CAD_symbol": "CA$",
	"USD_displayName": "ABD Doları",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "İngiliz Sterlini",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "Euro"
}
//end v1.x content
);